package br.com.teste.neon;

public class MedidorNeon {
	static {
		System.loadLibrary("MedidorNeonJni");
	}

	public static native int verificarNeon();

	public static native void prepararVetores();

	public static native void teste1();
	public static native void teste1Neon();

	public static native void teste2();
	public static native void teste2Neon();

	public static native void testeFPlay(byte[] bfft);
	public static native void testeFPlayNeon(byte[] bfft);
}
