package br.com.teste.neon;

import android.content.Context;
import android.os.AsyncTask;
import android.os.SystemClock;
import android.widget.Toast;

public class MedidorNeonTask extends AsyncTask<Integer, Integer, String> {
	private Context context;

	public MedidorNeonTask(Context context) {
		this.context = context;
	}

	@Override
	protected String doInBackground(Integer... x) {
		long t1 = 0, t2 = 0, t3 = 0;

		//Na vida real, verificarNeon() pode ser executado
		//apenas uma vez, durante a inicialização (não precisa
		//ser executado antes de cada método que utilizará NEON!)
		MedidorNeon.verificarNeon();

		MedidorNeon.prepararVetores();

		switch (x[0]) {
		case 0:
			byte[] bfft = new byte[1024];
			for (int i = 0; i < 1024; i++) {
				bfft[i] = (byte)(i >> 3);
			}
			t1  = SystemClock.uptimeMillis();
			MedidorNeon.testeFPlay(bfft);
			t2  = SystemClock.uptimeMillis();
			MedidorNeon.testeFPlayNeon(bfft);
			t3  = SystemClock.uptimeMillis();
			break;
		case 1:
			t1  = SystemClock.uptimeMillis();
			MedidorNeon.teste1();
			t2  = SystemClock.uptimeMillis();
			MedidorNeon.teste1Neon();
			t3  = SystemClock.uptimeMillis();
			break;
		case 2:
			t1  = SystemClock.uptimeMillis();
			MedidorNeon.teste2();
			t2  = SystemClock.uptimeMillis();
			MedidorNeon.teste2Neon();
			t3  = SystemClock.uptimeMillis();
			break;
		}

		return "Sem NEON: " + (t2 - t1) + "\nCom NEON: " + (t3 - t2);
	}

	@Override
	protected void onPostExecute(String s) {
		Toast.makeText(context, s, Toast.LENGTH_LONG).show();
	}
}
