package br.com.teste.neon;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity implements View.OnClickListener {

	private Button btnFPlay, btn1, btn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

	    btnFPlay = (Button)findViewById(R.id.btnFPlay);
	    btn1 = (Button)findViewById(R.id.btn1);
	    btn2 = (Button)findViewById(R.id.btn2);

	    btnFPlay.setOnClickListener(this);
		btn1.setOnClickListener(this);
	    btn2.setOnClickListener(this);
    }

	@Override
	public void onClick(View view) {
		if (view == btnFPlay) {
			(new MedidorNeonTask(getApplication())).execute(0);
		} else if (view == btn1) {
			(new MedidorNeonTask(getApplication())).execute(1);
		} else if (view == btn2) {
			(new MedidorNeonTask(getApplication())).execute(2);
		}
	}
}
