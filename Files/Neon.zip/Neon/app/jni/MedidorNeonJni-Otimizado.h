extern float vetorRes[];
extern float vetor1[];
extern float vetor2[];
extern float vetor3[];

extern void teste1NeonOtimizado();
extern void teste2NeonOtimizado();
extern void testeFPlayNeonOtimizado(signed char* bfft);
