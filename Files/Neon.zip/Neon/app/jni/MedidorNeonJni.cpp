#include <jni.h>
#include <math.h>

#ifdef __ARM_NEON__
#include <errno.h>
#include <fcntl.h>
#include "MedidorNeonJni-Otimizado.h"
#endif

float vetorRes[256] __attribute__((aligned(16)));
float vetor1[256] __attribute__((aligned(16)));
float vetor2[256] __attribute__((aligned(16)));
float vetor3[256] __attribute__((aligned(16)));

#ifdef __ARM_NEON__
int neonDisponivel, neonVerificado;
#endif

int JNICALL verificarNeon(JNIEnv* env, jclass clazz) {
#ifdef __ARM_NEON__
	if (neonVerificado == 1)
		return neonDisponivel;
	//Baseado em:
	//http://code.google.com/p/webrtc/source/browse/trunk/src/system_wrappers/source/android/cpu-features.c?r=2195
	//http://code.google.com/p/webrtc/source/browse/trunk/src/system_wrappers/source/android/cpu-features.h?r=2195
	neonDisponivel = 0;
	char cpuinfo[4096];
	int cpuinfo_len = -1;
	int fd = open("/proc/cpuinfo", O_RDONLY);
	if (fd >= 0) {
		do {
			cpuinfo_len = read(fd, cpuinfo, 4096);
		} while (cpuinfo_len < 0 && errno == EINTR);
		close(fd);
		if (cpuinfo_len > 0) {
			cpuinfo[cpuinfo_len] = 0;
			//procura pela linha "\nFeatures: "
			for (int i = cpuinfo_len - 9; i >= 0; i--) {
				if (memcmp(cpuinfo + i, "\nFeatures", 9) == 0) {
					i += 9;
					while (i < cpuinfo_len && (cpuinfo[i] == ' ' || cpuinfo[i] == '\t' || cpuinfo[i] == ':'))
						i++;
					cpuinfo_len -= 5;
					//agora, procura pela feature " neon"
					while (i <= cpuinfo_len && cpuinfo[i] != '\n') {
						if (memcmp(cpuinfo + i, " neon", 5) == 0 ||
							memcmp(cpuinfo + i, "\tneon", 5) == 0) {
							//temos NEON!!!
							neonDisponivel = 1;
							break;
						}
						i++;
					}
					break;
				}
			}
		}
	}
	neonVerificado = 1;
	return neonDisponivel;
#else
	return 0;
#endif
}

void JNICALL prepararVetores(JNIEnv* env, jclass clazz) {
	for (int i = 0; i < 256; i++) {
		vetor1[i] = 0.5f;
		vetor2[i] = 0.5f;
		vetor3[i] = 0.5f;
	}
}

void JNICALL teste1(JNIEnv* env, jclass clazz) {
	for (int c = 0; c < 1000000; c++) {
		for (int i = 0; i < 256; i++) {
			vetorRes[i] = vetor1[i] + (vetor2[i] * vetor3[i]);
		}
	}
}

void JNICALL teste1Neon(JNIEnv* env, jclass clazz) {
#ifdef __ARM_NEON__
	if (neonDisponivel)
		teste1NeonOtimizado();
	else
		teste1(env, clazz);
#else
	teste1(env, clazz);
#endif
}

void JNICALL teste2(JNIEnv* env, jclass clazz) {
	for (int c = 0; c < 1000000; c++) {
		for (int i = 0; i < 256; i++) {
			float f = vetor1[0];
			float a = vetor2[0] * f;
			float b = vetor3[0] * f;
			vetorRes[0] = ((a > b) ? a : b);
		}
	}
}

void JNICALL teste2Neon(JNIEnv* env, jclass clazz) {
#ifdef __ARM_NEON__
	if (neonDisponivel)
		teste2NeonOtimizado();
	else
		teste2(env, clazz);
#else
	teste2(env, clazz);
#endif
}

void JNICALL testeFPlay(JNIEnv* env, jclass clazz, jbyteArray jbfft) {
	//Adaptado de: https://github.com/carlosrafaelgn/FPlayAndroid

	signed char* bfft = (signed char*)env->GetPrimitiveArrayCritical(jbfft, 0);
	if (!bfft)
		return;

	for (int c = 0; c < 1000000; c++) {
		float* fft = vetor1;
		float* multiplier = vetor2;
		unsigned char* processedData = (unsigned char*)vetor3;
		float coefNew = 0.5f;
		float coefOld = 1.0f - coefNew;

		for (int i = 0; i < 256; i++) {
			const int re = (int)bfft[i << 1];
			const int im = (int)bfft[(i << 1) + 1];
			const int amplSq = (re * re) + (im * im);
			float m = ((amplSq < 8) ? 0.0f : (multiplier[i] * sqrtf((float)(amplSq))));
			const float old = fft[i];
			if (m < old)
				m = (coefNew * m) + (coefOld * old);
			fft[i] = m;
			const unsigned int v = ((unsigned int)m) >> 7;
			processedData[i] = ((v >= 255) ? 255 : (unsigned char)v);
		}
	}

	env->ReleasePrimitiveArrayCritical(jbfft, bfft, JNI_ABORT);
}

void JNICALL testeFPlayNeon(JNIEnv* env, jclass clazz, jbyteArray jbfft) {
#ifdef __ARM_NEON__
	if (neonDisponivel) {
		signed char* bfft = (signed char*)env->GetPrimitiveArrayCritical(jbfft, 0);
		if (!bfft)
			return;

		testeFPlayNeonOtimizado(bfft);

		env->ReleasePrimitiveArrayCritical(jbfft, bfft, JNI_ABORT);
	} else {
		testeFPlay(env, clazz, jbfft);
	}
#else
	testeFPlay(env, clazz, jbfft);
#endif
}

extern "C" {

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) {
#ifdef __ARM_NEON__
	neonDisponivel = 0;
	neonVerificado = 0;
#endif
	JNINativeMethod methodTable[] = {
		{"verificarNeon", "()I", (void*)verificarNeon},

		{"prepararVetores", "()V", (void*)prepararVetores},

		{"teste1", "()V", (void*)teste1},
		{"teste1Neon", "()V", (void*)teste1Neon},

		{"teste2", "()V", (void*)teste2},
		{"teste2Neon", "()V", (void*)teste2Neon},

		{"testeFPlay", "([B)V", (void*)testeFPlay},
		{"testeFPlayNeon", "([B)V", (void*)testeFPlayNeon}
	};
	JNIEnv* env;
	if (vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK)
		return -1;
	jclass clazz = env->FindClass("br/com/teste/neon/MedidorNeon");
	if (!clazz)
		return -1;
	env->RegisterNatives(clazz, methodTable, sizeof(methodTable) / sizeof(methodTable[0]));
	return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL JNI_OnUnload(JavaVM *vm, void *reserved) {
}

}
