#include <arm_neon.h>
#include "MedidorNeonJni-Otimizado.h"

void teste1NeonOtimizado() {
	for (int c = 0; c < 1000000; c++) {
		for (int i = 0; i < 256; i += 4) {
			vst1q_f32(vetorRes + i,
				vmlaq_f32(vld1q_f32(vetor1 + i), vld1q_f32(vetor2 + i), vld1q_f32(vetor3 + i))
			);
		}
	}
}

void teste2NeonOtimizado() {
	for (int c = 0; c < 1000000; c++) {
		for (int i = 0; i < 256; i += 4) {
			float32x4_t f = vld1q_f32(vetor1 + i);
			vst1q_f32(vetorRes + i,
				vmaxq_f32(
					vmulq_f32(vld1q_f32(vetor2 + i), f),
					vmulq_f32(vld1q_f32(vetor2 + i), f)
				)
			);
		}
	}
}

int intBuffer[4] __attribute__((aligned(16)));

void testeFPlayNeonOtimizado(signed char* bfft) {
	//Adaptado de: https://github.com/carlosrafaelgn/FPlayAndroid

	signed char* orBfft = bfft;

	for (int c = 0; c < 1000000; c++) {
		bfft = orBfft;
		float* fft = vetor1;
		float* multiplier = vetor2;
		unsigned char* processedData = (unsigned char*)vetor3;
		float coefNew = 0.5f;
		float coefOld = 1.0f - coefNew;
		int* tmpBuffer = intBuffer;

		for (int i = 0; i < 256; i += 8) {
			tmpBuffer[0] = ((int*)bfft)[0];
			tmpBuffer[1] = ((int*)bfft)[1];
			tmpBuffer[2] = ((int*)bfft)[2];
			tmpBuffer[3] = ((int*)bfft)[3];
			asm volatile (
				//q6 = multiplier
				"vld1.32 {d12, d13}, [%[multiplier]]!\n"

				//d0 = re re re re re re re re
				//d1 = im im im im im im im im
				"vld2.8 {d0, d1}, [%[tmpBuffer]]\n"

				"vmovl.s8 q1, d1\n" //q1 (d2,d3) = im im im im im im im im (int16)
				"vmovl.s8 q0, d0\n" //q0 (d0,d1) = re re re re re re re re (int16)

				"vmovl.s16 q3, d3\n" //q3 = im im im im (int32)
				"vmovl.s16 q2, d2\n" //q2 = im im im im (int32)
				"vmovl.s16 q1, d1\n" //q1 = re re re re (int32)
				"vmovl.s16 q0, d0\n" //q0 = re re re re (int32)

				"vmul.i32 q0, q0, q0\n" //q0 = re * re
				"vmul.i32 q1, q1, q1\n" //q1 = re * re

				"vmla.i32 q0, q2, q2\n" //q0 = q0 + (im * im)
				"vmla.i32 q1, q3, q3\n" //q1 = q1 + (im * im)

				"movs r6, #8\n"
				"vdupq.32 q3, r6\n" //q3 = 8

				"vcgeq.s32 q4, q0, q3\n" //q4 = (q0 >= 8)
				"vcgeq.s32 q5, q1, q3\n" //q5 = (q1 >= 8)

				"vcvt.f32.s32 q0, q0\n" //q0 = (float)q0
				"vcvt.f32.s32 q1, q1\n" //q1 = (float)q1

				//inspired by:
				//https://code.google.com/p/math-neon/source/browse/trunk/math_sqrtfv.c?r=25
				//http://www.mikusite.de/pages/vfp_neon.htm

				//compute the sqrt of q0 (the more steps, the more precision!)
				"vrsqrteq.f32 q3, q0\n" //q3 = ~1/sqrt(q0)

				"vmulq.f32 q2, q3, q0\n"
				"vrsqrtsq.f32 q2, q2, q3\n"
				"vmulq.f32 q3, q3, q2\n"

				"vmulq.f32 q2, q3, q0\n"
				"vrsqrtsq.f32 q2, q2, q3\n"
				"vmulq.f32 q3, q3, q2\n"

				"vmulq.f32 q2, q3, q0\n"
				"vrsqrtsq.f32 q2, q2, q3\n"
				"vmulq.f32 q3, q3, q2\n"

				"vmulq.f32 q0, q0, q3\n" //q0 = q0 * 1/sqrt(q0) :)
				"vandq q0, q0, q4\n" //q0 = q0 & q4 (remove NaN's, as 1/0 = Infinity, and x * Infinity = NaN)
				"vmulq.f32 q0, q0, q6\n"

				//compute the sqrt of q1 (the more steps, the more precision!)
				"vrsqrteq.f32 q3, q1\n" //q3 = ~1/sqrt(q0)

				"vmulq.f32 q2, q3, q1\n"
				"vrsqrtsq.f32 q2, q2, q3\n"
				"vmulq.f32 q3, q3, q2\n"

				"vmulq.f32 q2, q3, q1\n"
				"vrsqrtsq.f32 q2, q2, q3\n"
				"vmulq.f32 q3, q3, q2\n"

				"vmulq.f32 q2, q3, q1\n"
				"vrsqrtsq.f32 q2, q2, q3\n"
				"vmulq.f32 q3, q3, q2\n"

				"vmulq.f32 q1, q1, q3\n" //q1 = q1 * 1/sqrt(q1) :)
				"vandq q1, q1, q5\n" //q1 = q1 & q5 (remove NaN's, as 1/0 = Infinity, and x * Infinity = NaN)
				"vmulq.f32 q1, q1, q6\n"

				"ldr r6, %[coefNew]\n"
				"vdupq.32 q4, r6\n" //q4 = coefNew

				"ldr r6, %[coefOld]\n"
				"vdupq.32 q5, r6\n" //q5 = coefOld

				"vld1.32 {d12, d13}, [%[fft]]\n" //q6 = fft (old)
				"adds %[fft], #16\n"
				"vld1.32 {d14, d15}, [%[fft]]\n" //q7 = fft (old)
				"subs %[fft], #16\n"

				"vcgeq.f32 q2, q0, q6\n" //q2 = (m >= old) (q0 >= q6)
				"vcgeq.f32 q3, q1, q7\n" //q3 = (m >= old) (q1 >= q7)

				"vmulq.f32 q6, q5, q6\n" //q6 = (coefOld * old)
				"vmulq.f32 q7, q5, q7\n" //q7 = (coefOld * old)

				"vmla.f32 q6, q4, q0\n" //q6 = q6 + (coefNew * m)
				"vmla.f32 q7, q4, q1\n" //q7 = q7 + (coefNew * m)

				//if q2 = 1, use q0, otherwise, use q6
				"vandq q0, q0, q2\n"
				"vmvn q2, q2\n" //q2 = ~q2
				"vandq q6, q6, q2\n"
				"vorrq q0, q0, q6\n"

				//if q3 = 1, use q1, otherwise, use q7
				"vandq q1, q1, q3\n"
				"vmvn q3, q3\n" //q3 = ~q3
				"vandq q7, q7, q3\n"
				"vorrq q1, q1, q7\n"

				"vst1.32 {d0, d1}, [%[fft]]!\n"
				"vst1.32 {d2, d3}, [%[fft]]!\n"

				"vcvt.u32.f32 q0, q0\n" //q0 = (unsigned int)q0
				"vcvt.u32.f32 q1, q1\n" //q1 = (unsigned int)q1

				"vshrq.u32 q0, q0, #7\n" //q0 = q0 >> 7
				"vshrq.u32 q1, q1, #7\n" //q1 = q1 >> 7

				"vqmovn.u32 d4, q0\n" //d4 = (unsigned short)q0 [with saturation]
				"vqmovn.u32 d5, q1\n" //d5 = (unsigned short)q1 [with saturation]

				"vqmovn.u16 d0, q2\n" //d0 = (unsigned char)q2 [with saturation]

				"vst1.8 {d0}, [%[processedData]]!\n"

			: [multiplier] "+r" (multiplier), [processedData] "+r" (processedData), [fft] "+r" (fft)
			: [tmpBuffer] "r" (tmpBuffer), [coefNew] "m" (coefNew), [coefOld] "m" (coefOld)
			: "cc", "r6", "q0", "q1", "q2", "q3", "q4", "q5", "q6", "q7");
			bfft += 16;
		}
	}
}
